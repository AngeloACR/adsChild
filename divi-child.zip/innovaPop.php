<?php 
/* Template Name:innovaPop */

?>
<p class="innovaText">Somos una organización que diseña e implementa <span id="popTag">innovaciones políticas</span> para desarrollar democracias paritarias, inclusivas y participativas.</p>

 <div id="popText">
 <p>Por innovaciones políticas nos referimos al desarrollo de prácticas, intervenciones, dispositivos tecnológicos y/o regulaciones que permitan solucionar problemas públicos. Las innovaciones, entendemos, deben tener dos condiciones necesarias. La primera es que deben buscar transformarse en una práctica social y política generalizada, es decir, deben buscar tener un impacto político. La segunda es que deben favorecer a la ampliación de derechos y de calidad de vida de las personas. Entendida de este modo, la innovación política apunta a la construcción de sociedades abiertas, gobernadas por comunes, por lo que se requieren acciones que distribuyan el poder. Es por ello que, desde Asuntos del Sur, priorizamos las innovaciones centradas en la construcción de sociedades más paritarias, inclusivas y participativas. </p><br><br>
 </div>

 <p class="popResponsive">Por innovaciones políticas nos referimos al desarrollo de prácticas, intervenciones, dispositivos tecnológicos y/o regulaciones que permitan solucionar problemas públicos. Las innovaciones, entendemos, deben tener dos condiciones necesarias. La primera es que deben buscar transformarse en una práctica social y política generalizada, es decir, deben buscar tener un impacto político. La segunda es que deben favorecer a la ampliación de derechos y de calidad de vida de las personas. Entendida de este modo, la innovación política apunta a la construcción de sociedades abiertas, gobernadas por comunes, por lo que se requieren acciones que distribuyan el poder. Es por ello que, desde Asuntos del Sur, priorizamos las innovaciones centradas en la construcción de sociedades más paritarias, inclusivas y participativas. </p>

<style>	 
.innovaText{
	z-index: 10;
}

#popTag{
	font-weight: bold;
}

#popText{
	visibility: hidden;
	overflow: hidden;
	z-index: 10000;
	max-height: 0;
	padding-top: 10px;
	padding-left: 10px;
	transition: max-height 0.2s ease-out;
	width: 65vw;
	position: absolute;
	background-color: #e2e2e2;
	color: black;
	border-style: solid;
	border-width: 2px;
	border-color: black;
	border-radius: 10px;
}

.popResponsive{
	display: none;
}

@media screen and (max-width: 800px) {
  
  #popText{
  	display: none;
  }

  .popResponsive {
  	display: block;
	background-color: transparent;
	border: 0;
	position: relative;
	width: 100%;
  }
}

</style>

<script>
	var pop = document.getElementById("popTag");
	var popUp = document.getElementById("popText");

	pop.addEventListener("mouseover", function() {
    	popUp.style.visibility = "visible";	
		pop.addEventListener("mousemove", function(){
			posX = event.screenX/3;			
			popUp.style.top = 30 + "px";
			popUp.style.left = posX + "px";
		});
    	popUp.style.maxHeight = popUp.scrollHeight + "px";
	});

	pop.addEventListener("mouseout", function() {
		popUp.style.maxHeight = null;;
    	popUp.style.visibility = "hidden";	
	});

</script>