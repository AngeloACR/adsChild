<?php

function my_theme_enqueue_styles() {
    wp_enqueue_style( 'parent-style', get_template_directory_uri() . '/style.css' );
}
add_action( 'wp_enqueue_scripts', 'my_theme_enqueue_styles', 11 );


add_action('admin_head', 'my_custom_fonts');

function my_custom_fonts() {
	?>
		<link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
	<?php
}





/*
add_filter( 'wp_nav_menu_items', 'menuSocial', 10, 2 );
function menuSocial ( $items, $args ) {
    if (is_single() && $args->theme_location == 'primary') {
        $items .= '<a href="https://www.facebook.com/AsuntosDelSur.Latinoamerica"><img class="fIcon" src="/wp-content/uploads/icons/faceazul.png" alt=""></a>
            <a href="https://www.instagram.com/asuntosdelsur/"><img class="fIcon" src="/wp-content/uploads/icons/igazul.png" alt=""></a>
            <a href="https://twitter.com/asuntosdelsur"><img class="fIcon" src="/wp-content/uploads/icons/twitterazul.png" alt=""></a>
            <a href="https://www.linkedin.com/company/asuntos-del-sur"><img class="fIcon" src="/wp-content/uploads/icons/linkazul.png" alt=""></a>';
    }
    return $items;
}*/

include_once('adsshorts.php');
